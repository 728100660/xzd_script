### Markdown Text from Image 0_0.png

GitHub Issue - pulltext相关的issue，了解一下做的修改

输入 / 点击更多

我们的代码版本是2015.11.22 18点的包，现在需要同步github上面别人做出的rag更改，同步到我们的代码里面来：持续迭代任务

力。当模型的训练数据突破一定规模时，模型能够综合分析和解决更深层次的问题，展现出类似人类的思维和智能。这种涌现能力是大模型最显著的特点之一，也是其超越传统模型的关键所在。

https://www.google.com.hk/imgres?q=%E5%9B%BE%E7%89%87%E4%BA%BA%E5%83%8F&imgurl=https%3A%2F%2Fsydneyheadshot.net%2Fwp-content%2Fuploads%2F2020%2F06%2FYoshiko-Model-002-Edit-2-scaled.jpg&imgrefurl=https%3A%2F%2Fsydneyheadshot.net%2Fsession%2Fporetrait_photography_cn%2F&docid=z3zN2tF4FDnG5M&tbnid=q6po0MU4gKEwM&vet=12ahUKEwj51__D9K6NAxVexzgGHUKMA2YQM3oECHEQAA..i&w=2560&h=1709&hcb=2&ved=2ahUKEwj51__D9K6NAxVexzgGHUKMA2YQM3oECHEQAA

人像图片

### Markdown Text from Image 0_1.png

![](0_1.png)
